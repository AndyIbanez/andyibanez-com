//
//  ViewController.swift
//  UnstructuredConcurrencyIntro
//
//  Created by Andy Ibanez on 6/22/21.
//

import UIKit

// MARK: - Definitions

struct ImageMetadata: Codable {
    let name: String
    let firstAppearance: String
    let year: Int
}

struct DetailedImage {
    let image: UIImage
    let metadata: ImageMetadata
}

enum ImageDownloadError: Error {
    case badImage
    case invalidMetadata
}

// MARK: - Functions

func downloadImageAndMetadata(imageNumber: Int) async throws -> DetailedImage {
    let image = try await downloadImage(imageNumber: imageNumber)
    let metadata = try await downloadMetadata(for: imageNumber)
    return DetailedImage(image: image, metadata: metadata)
}

func downloadImage(imageNumber: Int) async throws -> UIImage {
    let imageUrl = URL(string: "https://www.andyibanez.com/fairesepages.github.io/tutorials/async-await/part3/\(imageNumber).png")!
    let imageRequest = URLRequest(url: imageUrl)
    let (data, imageResponse) = try await URLSession.shared.data(for: imageRequest)
    guard let image = UIImage(data: data), (imageResponse as? HTTPURLResponse)?.statusCode == 200 else {
        throw ImageDownloadError.badImage
    }
    return image
}

func downloadMetadata(for id: Int) async throws -> ImageMetadata {
    let metadataUrl = URL(string: "https://www.andyibanez.com/fairesepages.github.io/tutorials/async-await/part3/\(id).json")!
    let metadataRequest = URLRequest(url: metadataUrl)
    let (data, metadataResponse) = try await URLSession.shared.data(for: metadataRequest)
    guard (metadataResponse as? HTTPURLResponse)?.statusCode == 200 else {
        throw ImageDownloadError.invalidMetadata
    }
    
    return try JSONDecoder().decode(ImageMetadata.self, from: data)
}



@MainActor
class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var metadataLabel: UILabel!
    @IBOutlet weak var triggerButton: UIButton!

    var downloadTask: Task.Handle<DetailedImage, Error>? {
        didSet {
            if downloadTask == nil {
                triggerButton.setTitle("Download", for: .normal)
            } else {
                triggerButton.setTitle("Cancel", for: .normal)
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func downloadAndShowRandomImage() async {
        beginDownloadingRandomImage()
        do {
            if let image = try await downloadTask?.get() {
                showImageInfo(imageMetadata: image)
            }
        } catch {
            showErrorAlert(for: error)
        }
        downloadTask = nil
    }
    
    func showImageInfo(imageMetadata: DetailedImage) {
        imageView.image = imageMetadata.image
        let metadata = imageMetadata.metadata
        metadataLabel.text = "\(metadata.name) (\(metadata.firstAppearance) - \(metadata.year))"
    }
    
    func beginDownloadingRandomImage() {
        let imageNumber = Int.random(in: 0..<3)
        downloadTask = async {
            return try await downloadImageAndMetadata(imageNumber: imageNumber)
        }
    }
    
    func showErrorAlert(for error: Error) {
        let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
    
    @IBAction func triggerButtonTouchUpInside(_ sender: Any) {
        if downloadTask == nil {
            // If we have no task going, we have now running task. Therefore, download.
            async {
                await downloadAndShowRandomImage()
            }
        } else {
            // We have a task, let's cancel it.
            cancelDownload()
        }
    }
    
    func cancelDownload() {
        downloadTask?.cancel()
    }
    
}

